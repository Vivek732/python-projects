import uuid
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.urls import reverse


class Post(models.Model):
    post_id = models.UUIDField(primary_key=True, default = uuid.uuid4, editable=False)
    title = models.CharField(max_length=256)
    content = models.TextField()
    date_posted = models.DateTimeField(default=timezone.localtime)
    author = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self) -> str:
        return self.title

    
    def get_absolute_url(self):
        return reverse('post-detail',kwargs={'pk':self.pk})
#3fa37812-c5e6-4720-8eed-008a440ad147
